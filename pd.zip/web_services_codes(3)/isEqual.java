package web_services_codes;

public class isEqual {
	public static boolean strEqual(String str1, String str2){
		return str1 == str2 ;
	}
	public static void main(String[] args) {
		System.out.println(strEqual("ayush","ayush"));
		
	}
}

