package SocketProgram;

import java.util.*;
import java.net.*;
public class sender {
	
  public static void main(String args[])throws Exception {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter your message");
	String str=sc.nextLine();
	DatagramSocket ds=new DatagramSocket();
	InetAddress ip=InetAddress.getByName("127.0.0.1");
	System.out.println();
	DatagramPacket dp=new DatagramPacket(str.getBytes(),str.length(),ip,2000);
	ds.send(dp);
	ds.close();
	System.out.println("Message hs been sent to the receiver"+str);
	
	
	
	
   }
}
